# import 모듈 가져 오기
# datetime-> 기본 날자와 시간형 모듈
# os -> 환경 변수나 디렉터리, 파일 등의 OS 자원을 제어할 수있게 해주는 모듈
# sys -> 파이썬 인터프리터가 제공하는 변수와 함수를 직접 제어할 수 있게 해주는 모듈
import datetime as dt, os, sys

# yml.mk_yml 모듈 가져 오고, mkYml 별칭 으로 사용
import yml.mk_yml as mkYml

# conn.oracle 모듈 가져 오고, oraConn 별칭 으로 사용.
import conn.oracle as oraConn

# conn.mysql 모듈 가져 오고, myConn 별칭 으로 사용.

import conn.mysql as myConn

# TODO : Oracle Home, Mysql Home, Embulk 환경변수 셋팅 (Home, Log 디렉토리)

#global 전역 변수 선언 - oracle 설치 경로, mysql 설치 경로, embulk 설치 경로
global oraHomePath
global myHomePath
global emHomePath

# def 는 함수를 만들 때 사용 하는 예약어, 함수 명 임의 생성 가능.
# main 함수 생성 및 os.putenv 모듈을 이용해 환경 변수 지정.
def main():
    os.putenv('NLS_LANG', '.UTF8')
    os.putenv('TNS_ADMIN', r'C:\app\client\product\19.0.0\client_1\network\admin')
    # Home 경로 테스트용으로 지정 -- 추후 입력 받는 방식으로 수정
    oraHomePath = r"/app/oracle/product/19c/dbhome_1"
    myHomePath = r"/app/mysql"
    emHomePath = r"C:\embulk"

    # mk_yml 파일 실행
    srcConfig, tgtConfig = mkYml.main()

    # Source (oracle) DB 접속
    srcConn = oraConn.startConn(srcConfig)
    if srcConn:
        print ('\n\n' + srcConfig.dbName + " Connected.")

if __name__ == "__main__":
    main()